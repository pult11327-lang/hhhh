package com.example.dragauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter

class DragAccessibilityService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { when(i?.action) { Actions.START -> startRun(); Actions.STOP -> stopRun() } }
    }
    override fun onServiceConnected() {
        super.onServiceConnected()
        val f = IntentFilter().apply { addAction(Actions.START); addAction(Actions.STOP) }
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") run { registerReceiver(receiver, f) }
    }
    override fun onDestroy() { stopRun(); runCatching { unregisterReceiver(receiver) }; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopRun() }

    private fun startRun() {
        if (running) return
        running = true
        val prefs = getSharedPreferences("run", 0)
        val warm = prefs.getLong("warm", 1800L)
        val start = prefs.getLong("start", 700L)
        val profile = prefs.getString("profile", "Default") ?: "Default"
        val mode = prefs.getString("mode", "AUTO") ?: "AUTO"
        val shiftString = if (mode == "AUTO") {
            AutoShiftLearner.current(this, profile, prefs.getString("shifts", "1050,1450,1750,2050,2350") ?: "1050,1450,1750,2050,2350")
        } else {
            prefs.getString("shifts", "1050,1450,1750,2050,2350") ?: "1050,1450,1750,2050,2350"
        }
        val base = shiftString.split(",").mapNotNull { it.trim().toLongOrNull() }
            .filter { it >= 0 }.toLongArray().ifEmpty { longArrayOf(1050,1450,1750,2050,2350) }
        val off = Optimizer.offset()
        prefs.edit().putString(DebugState.STATUS, "Автозаезд запущен").apply()

        tap(Constants.THROTTLE)
        h.postDelayed({ tap(Constants.CLUTCH) }, 250)
        h.postDelayed({ tap(Constants.THROTTLE) }, 500)
        h.postDelayed({ tap(Constants.CLUTCH) }, 750)
        h.postDelayed({ tap(Constants.THROTTLE) }, warm)
        h.postDelayed({ tap(Constants.THROTTLE) }, warm + start)
        base.forEach { t -> h.postDelayed({ if (running) tap(Constants.SHIFT_UP) }, (warm + start + t + off).coerceAtLeast(0L)) }
        h.postDelayed({ if (running) { running = false; prefs.edit().putString(DebugState.STATUS, "Автозаезд завершён").apply() } }, warm + start + base.maxOrNull()!! + 1200)
    }

    private fun stopRun() {
        running = false
        h.removeCallbacksAndMessages(null)
        getSharedPreferences("run", 0).edit().putString(DebugState.STATUS, "Остановлено").apply()
    }

    private fun tap(p: P, duration: Long = 45) {
        if (!running) return
        val x = p.x * resources.displayMetrics.widthPixels
        val y = p.y * resources.displayMetrics.heightPixels
        val path = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build(), null, null)
    }
}
