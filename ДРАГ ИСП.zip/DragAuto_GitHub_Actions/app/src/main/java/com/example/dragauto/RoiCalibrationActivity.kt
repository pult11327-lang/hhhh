package com.example.dragauto

import android.app.Activity
import android.graphics.*
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import kotlin.math.abs
import kotlin.math.min

class RoiCalibrationActivity : Activity() {
    private lateinit var roiView: RoiView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("run", 0)
        val frame = BitmapFactory.decodeFile(File(filesDir, "latest_frame.jpg").absolutePath)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }
        root.addView(TextView(this).apply {
            text = if (frame == null)
                "Нет кадра. Включите MediaProjection и подождите 1–2 секунды."
            else
                "Перетащите жёлтую рамку на цифры таймера. Для новой области коснитесь вне рамки и протяните."
            textSize = 16f
        })
        roiView = RoiView(this, frame, prefs)
        root.addView(roiView, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this)
        row.addView(Button(this).apply {
            text = "Сбросить"
            setOnClickListener { roiView.reset() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "Сохранить ROI"
            setOnClickListener { roiView.save(); setResult(RESULT_OK); finish() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        setContentView(root)
    }
}

private class RoiView(
    context: android.content.Context,
    private val bitmap: Bitmap?,
    private val prefs: android.content.SharedPreferences
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var rx = prefs.getFloat("roi_x", 0f)
    private var ry = prefs.getFloat("roi_y", 0f)
    private var rw = prefs.getFloat("roi_w", 1f)
    private var rh = prefs.getFloat("roi_h", 1f)
    private var downX = 0f
    private var downY = 0f
    private var mode = 0
    private val minSize = 0.05f

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        if (bitmap == null) return
        val scale = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val dw = bitmap.width * scale
        val dh = bitmap.height * scale
        val ox = (width - dw) / 2f
        val oy = (height - dh) / 2f
        canvas.drawBitmap(bitmap, null, RectF(ox, oy, ox + dw, oy + dh), paint)

        val r = RectF(ox + rx*dw, oy + ry*dh, ox + (rx+rw)*dw, oy + (ry+rh)*dh)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(75, 255, 235, 59)
        canvas.drawRect(r, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        paint.color = Color.YELLOW
        canvas.drawRect(r, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.textSize = 28f
        canvas.drawText("ROI", r.left + 8f, r.top + 32f, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bitmap == null) return false
        val scale = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val dw = bitmap.width * scale
        val dh = bitmap.height * scale
        val ox = (width - dw) / 2f
        val oy = (height - dh) / 2f
        val x = ((e.x - ox) / dw).coerceIn(0f, 1f)
        val y = ((e.y - oy) / dh).coerceIn(0f, 1f)

        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = x; downY = y
                mode = if (x >= rx && x <= rx+rw && y >= ry && y <= ry+rh) 1 else 2
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 1) {
                    val dx = x - downX
                    val dy = y - downY
                    rx = (rx + dx).coerceIn(0f, 1f-rw)
                    ry = (ry + dy).coerceIn(0f, 1f-rh)
                    downX = x; downY = y
                } else {
                    val left = min(downX, x)
                    val top = min(downY, y)
                    val w = abs(x-downX)
                    val h = abs(y-downY)
                    if (w >= minSize && h >= minSize) {
                        rx = left.coerceIn(0f, 1f-minSize)
                        ry = top.coerceIn(0f, 1f-minSize)
                        rw = w.coerceIn(minSize, 1f-rx)
                        rh = h.coerceIn(minSize, 1f-ry)
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> { mode = 0; return true }
        }
        return true
    }

    fun reset() { rx=0f; ry=0f; rw=1f; rh=1f; invalidate() }

    fun save() {
        prefs.edit().putFloat("roi_x",rx).putFloat("roi_y",ry)
            .putFloat("roi_w",rw).putFloat("roi_h",rh).apply()
    }
}
