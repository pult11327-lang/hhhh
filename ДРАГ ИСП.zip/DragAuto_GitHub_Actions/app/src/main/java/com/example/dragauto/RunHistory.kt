package com.example.dragauto

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Lightweight local history without an extra database dependency. */
object RunHistory {
    data class Run(val time: Double, val target: Double, val offset: Long, val profile: String, val at: Long)
    private const val PREFS = "history"
    private const val KEY = "runs"

    @Synchronized fun add(context: Context, time: Double, target: Double, offset: Long, profile: String) {
        val prefs = context.getSharedPreferences(PREFS, 0)
        val old = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrDefault(JSONArray())
        val out = JSONArray()
        val item = JSONObject().apply {
            put("time", time); put("target", target); put("offset", offset)
            put("profile", profile); put("at", System.currentTimeMillis())
        }
        out.put(item)
        for (i in 0 until minOf(old.length(), 49)) out.put(old.getJSONObject(i))
        prefs.edit().putString(KEY, out.toString()).apply()
    }

    fun list(context: Context): List<Run> {
        val a = runCatching { JSONArray(context.getSharedPreferences(PREFS, 0).getString(KEY, "[]")) }
            .getOrDefault(JSONArray())
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(Run(o.optDouble("time"), o.optDouble("target"), o.optLong("offset"), o.optString("profile", "Default"), o.optLong("at")))
            }
        }
    }

    fun summary(context: Context): String {
        val r = list(context)
        if (r.isEmpty()) return "История: пока нет сохранённых заездов"
        val best = r.minByOrNull { kotlin.math.abs(it.time - it.target) }!!
        return "Заездов: ${r.size} • лучший: %.3f с • offset: %d мс".format(best.time, best.offset)
    }
}
