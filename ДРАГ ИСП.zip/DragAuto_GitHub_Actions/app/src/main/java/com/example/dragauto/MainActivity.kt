package com.example.dragauto

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private val mediaProjectionRequest = 4101
    private lateinit var target: EditText
    private lateinit var startDelay: EditText
    private lateinit var shifts: EditText
    private lateinit var interval: EditText
    private lateinit var profileName: EditText
    private lateinit var profileSpinner: Spinner
    private lateinit var modeSpinner: Spinner
    private lateinit var offset: TextView
    private lateinit var result: EditText
    private lateinit var debug: TextView
    private lateinit var history: TextView
    private lateinit var status: TextView
    private lateinit var roiStatus: TextView
    private lateinit var autoSummary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 32)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "DRAG AUTO • v3"
            textSize = 28f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Управление автоматизацией и AUTO LEARN"
            textSize = 15f
        })

        status = TextView(this).apply { textSize = 15f; setPadding(0, 14, 0, 14) }
        root.addView(status)

        addSection(root, "1. ДОСТУП И ЗАХВАТ")
        root.addView(actionButton("♿ Accessibility", "Открыть настройки Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(actionButton("🎥 MediaProjection", "Включить захват экрана") {
            requestScreenCapture()
        })
        root.addView(actionButton("🎯 ROI таймера", "Калибровка области OCR") {
            startActivity(Intent(this, RoiCalibrationActivity::class.java))
        })

        addSection(root, "2. ПРОФИЛЬ")
        profileName = field("Название профиля", "Default")
        root.addView(profileName)
        profileSpinner = Spinner(this)
        root.addView(profileSpinner)
        root.addView(actionButton("💾 Сохранить профиль", "Сохранить текущие параметры") {
            ProfileStore.save(this, profileName.text.toString(), targetValue(), startValue(), shifts.text.toString(), warmValue())
            refreshProfiles()
            Toast.makeText(this, "Профиль сохранён", Toast.LENGTH_SHORT).show()
            refresh()
        })

        addSection(root, "3. РЕЖИМ")
        modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("AUTO — приложение обучается само", "MANUAL — timing задаю сам")
            )
        }
        root.addView(modeSpinner)

        target = field("Целевое время, сек", "8.50"); root.addView(target)
        startDelay = field("Задержка старта, мс", "700"); root.addView(startDelay)
        shifts = field("Timing переключений, мс", "1050,1450,1750,2050,2350"); root.addView(shifts)
        interval = field("Прогрев, мс", "1800"); root.addView(interval)

        root.addView(actionButton("♻️ Сбросить AUTO-обучение", "Начать обучение выбранного профиля заново") {
            val profile = profileName.text.toString().ifBlank { "Default" }
            AutoShiftLearner.reset(this, profile)
            Toast.makeText(this, "AUTO-обучение профиля сброшено", Toast.LENGTH_SHORT).show()
            refresh()
        })

        addSection(root, "4. ЗАПУСК")
        root.addView(actionButton("▶ ЗАПУСТИТЬ AUTO", "Сохранить настройки и начать автозаезд") {
            startAutoRun()
        })
        root.addView(actionButton("🛑 STOP", "Немедленно остановить автозаезд и захват") {
            stopAll()
        })

        addSection(root, "5. AUTO LEARN")
        autoSummary = TextView(this).apply { textSize = 14f; setPadding(0, 4, 0, 12) }
        root.addView(autoSummary)
        offset = TextView(this).apply { textSize = 14f }
        root.addView(offset)
        result = field("Последнее время / результат, сек", "")
        root.addView(result)
        root.addView(actionButton("📈 Сохранить результат + обучить", "Передать результат в AUTO LEARN") {
            saveResult()
        })

        addSection(root, "6. ДИАГНОСТИКА")
        debug = TextView(this).apply { textSize = 14f; setPadding(0, 4, 0, 8) }
        root.addView(debug)
        roiStatus = TextView(this).apply { textSize = 14f; setPadding(0, 4, 0, 12) }
        root.addView(roiStatus)
        root.addView(actionButton("🔎 DEBUG", "Показать подробное состояние OCR и автоматизации") {
            showDebugDialog()
        })
        root.addView(actionButton("📊 ИСТОРИЯ", "Показать сохранённые заезды") {
            showHistoryDialog()
        })
        root.addView(actionButton("🔄 Обновить статус", "Перечитать состояние сервисов") {
            refresh()
            Toast.makeText(this, "Статус обновлён", Toast.LENGTH_SHORT).show()
        })

        profileSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val name = parent?.getItemAtPosition(position)?.toString() ?: return
                ProfileStore.load(this@MainActivity, name)?.let { o ->
                    target.setText(o.optDouble("target", 8.5).toString())
                    startDelay.setText(o.optLong("start", 700).toString())
                    shifts.setText(o.optString("shifts", "1050,1450,1750,2050,2350"))
                    interval.setText(o.optLong("warm", 1800).toString())
                    profileName.setText(name)
                }
                refresh()
            }
        }

        refreshProfiles()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refreshProfiles()
        refresh()
    }

    private fun addSection(root: LinearLayout, title: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 18f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 20, 0, 8)
        })
    }

    private fun actionButton(title: String, subtitle: String, action: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 3, 0, 3)
        }
        val b = Button(this).apply {
            text = title
            textSize = 16f
            isAllCaps = false
            setOnClickListener { action() }
        }
        val s = TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(12, 0, 12, 4)
        }
        box.addView(b)
        box.addView(s)
        return box
    }

    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        inputType = android.text.InputType.TYPE_CLASS_TEXT
        textSize = 16f
        setSingleLine(true)
    }

    private fun targetValue() = target.text.toString().replace(',', '.').toDoubleOrNull() ?: 8.50
    private fun startValue() = startDelay.text.toString().toLongOrNull()?.coerceIn(0, 10000) ?: 700L
    private fun warmValue() = interval.text.toString().toLongOrNull()?.coerceIn(0, 10000) ?: 1800L

    private fun saveResult() {
        val actual = result.text.toString().replace(',', '.').toDoubleOrNull()
        if (actual == null) {
            Toast.makeText(this, "Введи результат, например 8.42", Toast.LENGTH_SHORT).show()
            return
        }
        val profile = profileName.text.toString().ifBlank { "Default" }
        val mode = if (modeSpinner.selectedItemPosition == 0) "AUTO" else "MANUAL"
        val learned = if (mode == "AUTO") {
            AutoShiftLearner.record(this, profile, shifts.text.toString(), actual, targetValue())
        } else shifts.text.toString()
        shifts.setText(learned)
        val off = Optimizer.record(actual, targetValue())
        RunHistory.add(this, actual, targetValue(), off, profile)
        getSharedPreferences("run", 0).edit().putString("shifts", learned).apply()
        refresh()
        Toast.makeText(this, "Результат сохранён, AUTO LEARN обновлён", Toast.LENGTH_SHORT).show()
    }

    private fun startAutoRun() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Сначала включи Accessibility для Drag Auto", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        saveConfig()
        getSharedPreferences(DebugState.PREFS, 0).edit().putString(DebugState.STATUS, "Запуск автозаезда…").apply()
        sendBroadcast(Intent(Actions.START).setPackage(packageName))
        Toast.makeText(this, "AUTO запущен", Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun stopAll() {
        sendBroadcast(Intent(Actions.STOP).setPackage(packageName))
        startService(Intent(this, MediaProjectionCaptureService::class.java).setAction(MediaProjectionCaptureService.ACTION_STOP))
        getSharedPreferences(DebugState.PREFS, 0).edit().putString(DebugState.STATUS, "Остановлено пользователем").apply()
        Toast.makeText(this, "STOP", Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(manager.createScreenCaptureIntent(), mediaProjectionRequest)
    }

    @Deprecated("Use Activity Result API in a future cleanup")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != mediaProjectionRequest || resultCode != RESULT_OK || data == null) {
            if (requestCode == mediaProjectionRequest) Toast.makeText(this, "Захват экрана не разрешён", Toast.LENGTH_SHORT).show()
            return
        }
        val i = Intent(this, MediaProjectionCaptureService::class.java).apply {
            action = MediaProjectionCaptureService.ACTION_START
            putExtra(MediaProjectionCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(MediaProjectionCaptureService.EXTRA_RESULT_DATA, data)
        }
        ContextCompat.startForegroundService(this, i)
        getSharedPreferences(DebugState.PREFS, 0).edit().putString(DebugState.STATUS, "Захват экрана активен").apply()
        Toast.makeText(this, "MediaProjection включён", Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun saveConfig() {
        val profile = profileName.text.toString().ifBlank { "Default" }
        getSharedPreferences("run", 0).edit()
            .putLong("start", startValue())
            .putString("shifts", shifts.text.toString())
            .putLong("warm", warmValue())
            .putFloat("target", targetValue().toFloat())
            .putString("profile", profile)
            .putString("mode", if (modeSpinner.selectedItemPosition == 0) "AUTO" else "MANUAL")
            .apply()
    }

    private fun refreshProfiles() {
        if (!::profileSpinner.isInitialized) return
        val names = ProfileStore.names(this)
        val wanted = if (::profileName.isInitialized) profileName.text.toString() else "Default"
        profileSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val idx = names.indexOf(wanted)
        if (idx >= 0) profileSpinner.setSelection(idx, false)
    }

    private fun refresh() {
        if (!::offset.isInitialized) return
        val profile = profileName.text.toString().ifBlank { "Default" }
        val prefs = getSharedPreferences("run", 0)
        val debugPrefs = getSharedPreferences(DebugState.PREFS, 0)
        val ocr = debugPrefs.getFloat(DebugState.OCR, Float.NaN)
        val debugStatus = debugPrefs.getString(DebugState.STATUS, "Ожидание") ?: "Ожидание"
        val roiX = prefs.getFloat("roi_x", 0f)
        val roiY = prefs.getFloat("roi_y", 0f)
        val roiW = prefs.getFloat("roi_w", 1f)
        val roiH = prefs.getFloat("roi_h", 1f)
        val roiSet = prefs.contains("roi_x")
        val access = if (isAccessibilityEnabled()) "ВКЛ" else "ВЫКЛ"
        val mode = prefs.getString("mode", "AUTO") ?: "AUTO"
        status.text = "Статус: Accessibility $access • MediaProjection: ${if (debugStatus.contains("захват", true) || debugStatus.contains("OCR", true)) "ВКЛ" else "—"} • Режим: $mode"
        autoSummary.text = AutoShiftLearner.summary(this, profile)
        offset.text = "🤖 Optimizer offset: ${Optimizer.offset()} мс"
        debug.text = if (ocr.isNaN()) "🔎 OCR: — • состояние: $debugStatus" else "🔎 OCR: %.3f с • состояние: %s • offset: %d мс".format(ocr, debugStatus, Optimizer.offset())
        roiStatus.text = "🎯 ROI: ${if (roiSet) "настроен" else "по умолчанию"} • x=${(roiX * 100).roundToInt()}% y=${(roiY * 100).roundToInt()}% w=${(roiW * 100).roundToInt()}% h=${(roiH * 100).roundToInt()}%\n📊 ${RunHistory.summary(this)}"
    }

    private fun showDebugDialog() {
        val p = getSharedPreferences(DebugState.PREFS, 0)
        val run = getSharedPreferences("run", 0)
        val ocr = p.getFloat(DebugState.OCR, Float.NaN)
        val profile = run.getString("profile", "Default") ?: "Default"
        val text = buildString {
            append("Профиль: $profile\n")
            append("Режим: ${run.getString("mode", "AUTO")}\n")
            append("Статус: ${p.getString(DebugState.STATUS, "Ожидание")}\n")
            append("OCR: ${if (ocr.isNaN()) "нет данных" else "%.3f с".format(ocr)}\n")
            append("Timer: ${run.getFloat("screen_timer", Float.NaN)}\n")
            append("Optimizer offset: ${Optimizer.offset()} мс\n")
            append("AUTO: ${AutoShiftLearner.summary(this@MainActivity, profile)}\n")
            append("ROI настроен: ${run.contains("roi_x")}")
        }
        AlertDialog.Builder(this).setTitle("DEBUG").setMessage(text).setPositiveButton("OK", null).show()
    }

    private fun showHistoryDialog() {
        val runs = RunHistory.list(this)
        val text = if (runs.isEmpty()) "Пока нет сохранённых заездов." else buildString {
            runs.take(20).forEachIndexed { index, r ->
                append("${index + 1}. ${"%.3f".format(r.time)} с / цель ${"%.3f".format(r.target)} с • offset ${r.offset} мс • ${r.profile}\n")
            }
        }
        AlertDialog.Builder(this).setTitle("История заездов").setMessage(text).setPositiveButton("Закрыть", null).show()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val expected = ComponentName(this, DragAccessibilityService::class.java)
        return enabled.any { info -> info.resolveInfo?.serviceInfo?.let { ComponentName(it.packageName, it.name) == expected } == true }
    }
}

object Actions {
    const val START = "com.example.dragauto.START"
    const val STOP = "com.example.dragauto.STOP"
}
