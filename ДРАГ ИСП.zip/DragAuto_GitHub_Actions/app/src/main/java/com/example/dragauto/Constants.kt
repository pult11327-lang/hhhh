package com.example.dragauto

// Координаты нормализованы: 0..1 от ширины/высоты экрана.
// По присланной записи 1624x720: газ ≈ (0.945,0.84), + передача ≈ (0.33,0.82).
object Constants {
    val THROTTLE = P(0.945f, 0.84f)
    val SHIFT_UP = P(0.335f, 0.82f)
    val CLUTCH = P(0.075f, 0.84f)
    val BRAKE = P(0.16f, 0.84f)
    // Если в твоей версии кнопки отличаются, меняются только эти значения.
}
data class P(val x: Float, val y: Float)
