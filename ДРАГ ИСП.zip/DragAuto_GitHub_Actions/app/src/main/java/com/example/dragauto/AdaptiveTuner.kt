package com.example.dragauto

import kotlin.math.abs

/** Небольшая адаптация общего сдвига по фактическому времени заезда. */
object AdaptiveTuner {
    private var offsetMs = 0L
    private var previousError: Double? = null
    @Synchronized fun offset(): Long = offsetMs
    @Synchronized fun update(actualSeconds: Double, targetSeconds: Double): Long {
        if (!actualSeconds.isFinite() || !targetSeconds.isFinite() || actualSeconds <= 0 || targetSeconds <= 0) return offsetMs
        val errorMs = (actualSeconds - targetSeconds) * 1000.0
        val step = errorMs.coerceIn(-40.0, 40.0).toLong()
        // Если ошибка улучшилась — продолжаем в том же направлении; иначе уменьшаем шаг.
        val prev = previousError
        offsetMs = if (prev == null || abs(errorMs) < abs(prev)) offsetMs - step else offsetMs - (step / 2)
        offsetMs = offsetMs.coerceIn(-250L, 250L)
        previousError = errorMs
        return offsetMs
    }
}
