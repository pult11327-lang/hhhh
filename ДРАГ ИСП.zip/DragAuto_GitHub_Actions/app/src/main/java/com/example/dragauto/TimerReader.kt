package com.example.dragauto

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executor
import kotlin.math.abs

/** OCR with simple temporal validation to reject one-frame garbage. */
object TimerReader {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    @Volatile private var lastValue: Double? = null
    @Volatile private var stableCount = 0

    fun readSeconds(bitmap: Bitmap, executor: Executor, callback: (Double?) -> Unit) {
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener(executor) { result ->
                val text = result.text.replace(',', '.')
                val candidates = Regex("(?<!\\d)(\\d{1,2}\\.\\d{1,3})(?!\\d)")
                    .findAll(text).mapNotNull { it.value.toDoubleOrNull() }.filter { it in 0.0..999.0 }.toList()
                val value = candidates.minByOrNull { abs(it - (lastValue ?: it)) }
                val accepted = if (value == null) null else {
                    val prev = lastValue
                    if (prev == null || abs(value - prev) < 5.0) {
                        stableCount++
                        if (stableCount >= 2) lastValue = value
                        value
                    } else {
                        stableCount = 0
                        null
                    }
                }
                callback(accepted)
            }
            .addOnFailureListener(executor) { callback(null) }
    }
}
