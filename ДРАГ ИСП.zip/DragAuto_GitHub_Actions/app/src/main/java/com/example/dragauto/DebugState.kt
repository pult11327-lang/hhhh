package com.example.dragauto

object DebugState {
    const val PREFS = "run"
    const val STATUS = "debug_status"
    const val OCR = "screen_timer"
}
